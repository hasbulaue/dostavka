// Второй код (для страницы заказа)
console.log(sessionStorage.getItem('cart_items'))

const products = [
    { id: 1, name: "Товар 1", image: "/static/images/black.jpg", price: 100 },
    { id: 2, name: "Товар 2", image: "/static/images/black.jpg", price: 200 },
    { id: 3, name: "Товар 3", image: "/static/images/black.jpg", price: 150 },
    { id: 4, name: "Товар 4", image: "/static/images/black.jpg", price: 300 },
    { id: 5, name: "Товар 5", image: "/static/images/black.jpg", price: 250 },
    { id: 6, name: "Товар 6", image: "/static/images/black.jpg", price: 180 },
    { id: 7, name: "Товар 7", image: "/static/images/black.jpg", price: 220 },
    { id: 8, name: "Товар 8", image: "/static/images/black.jpg", price: 190 },
    { id: 9, name: "Товар 9", image: "/static/images/black.jpg", price: 270 },
    { id: 10, name: "Товар 10", image: "/static/images/black.jpg", price: 320 },
    { id: 11, name: "Товар 11", image: "/static/images/black.jpg", price: 140 },
    { id: 12, name: "Товар 12", image: "/static/images/black.jpg", price: 210 },
    { id: 13, name: "Товар 1", image: "/static/images/black.jpg", price: 100 },
    { id: 14, name: "Товар 2", image: "/static/images/black.jpg", price: 200 },
    { id: 15, name: "Товар 3", image: "/static/images/black.jpg", price: 150 },
    { id: 16, name: "Товар 4", image: "/static/images/black.jpg", price: 300 },
    { id: 17, name: "Товар 5", image: "/static/images/black.jpg", price: 250 },
    { id: 18, name: "Товар 6", image: "/static/images/black.jpg", price: 180 },
    { id: 19, name: "Товар 7", image: "/static/images/black.jpg", price: 220 },
    { id: 20, name: "Товар 8", image: "/static/images/black.jpg", price: 190 },
    { id: 21, name: "Товар 9", image: "/static/images/black.jpg", price: 270 },
    { id: 22, name: "Товар 10", image: "/static/images/black.jpg", price: 320 },
    { id: 23, name: "Товар 11", image: "/static/images/black.jpg", price: 140 },
    { id: 24, name: "Товар 12", image: "/static/images/black.jpg", price: 210 }
];

function updateOrderTotal() {
  const cartItems = sessionStorage.getItem('cart_items');
  let totalPrice = 0;
  
  if (cartItems) {
    const itemIds = cartItems.split(',').map(id => parseInt(id.trim()));
    itemIds.forEach(id => {
      const product = products.find(p => p.id === id);
      if (product) {
        totalPrice += product.price;
      }
    });
  }
  
  const totalPriceElement = document.getElementById('order-total');
  if (totalPriceElement) {
    totalPriceElement.textContent = `Общая сумма заказа: ${totalPrice} руб.`;
  }
}

function orderProducts() {
    const cartItems = sessionStorage.getItem('cart_items');
    const container = document.getElementById('products-container');
    container.innerHTML = '';

    if (cartItems) {
        const itemIds = cartItems.split(',').map(id => parseInt(id.trim()));
        const itemCounts = {};
        
        itemIds.forEach(id => {
            itemCounts[id] = (itemCounts[id] || 0) + 1;
        });

        Object.keys(itemCounts).forEach(id => {
            const productId = parseInt(id);
            const product = products.find(p => p.id === productId);
            if (product) {
                const div = document.createElement('div');
                div.classList.add('product');
                div.innerHTML = `
                    <img src="${product.image}" alt="${product.name}">
                    <p>${product.name}</p>
                    <p class="price">${product.price} руб.</p>
                    <div class="quantity-controls">
                        <button class="decrease-btn" data-id="${product.id}">-</button>
                        <span class="quantity" data-id="${product.id}">${itemCounts[productId]}</span>
                        <button class="increase-btn" data-id="${product.id}">+</button>
                    </div>
                `;

                // Обработчики для кнопок +/-
                div.querySelector('.increase-btn').addEventListener('click', function() {
                    const currentItems = sessionStorage.getItem('cart_items');
                    if (currentItems) {
                        sessionStorage.setItem('cart_items', currentItems + ',' + this.dataset.id);
                    } else {
                        sessionStorage.setItem('cart_items', this.dataset.id);
                    }
                    orderProducts();
                    console.log('Товар добавлен в корзину');
                });

                div.querySelector('.decrease-btn').addEventListener('click', function() {
                    const currentItems = sessionStorage.getItem('cart_items');
                    if (currentItems) {
                        const itemsArray = currentItems.split(',');
                        const index = itemsArray.indexOf(this.dataset.id);
                        if (index !== -1) {
                            itemsArray.splice(index, 1);
                            sessionStorage.setItem('cart_items', itemsArray.join(','));
                            orderProducts();
                            console.log('Товар удален из корзины');
                        }
                    }
                });

                container.appendChild(div);
            }
        });
    }
    
    updateOrderTotal();
}

// Добавляем элемент для отображения общей суммы заказа
const orderTotalElement = document.createElement('div');
orderTotalElement.id = 'order-total';
orderTotalElement.classList.add('order-total');
document.body.appendChild(orderTotalElement);

orderProducts();