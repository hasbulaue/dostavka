const products = [
    { id: 1, name: "Товар 1", image:"/static/images/black.jpg" },
    { id: 2, name: "Товар 2" },
    { id: 3, name: "Товар 3" },
    { id: 4, name: "Товар 4" },
    { id: 5, name: "Товар 5" },
    { id: 6, name: "Товар 6" },
    { id: 7, name: "Товар 7" },
    { id: 8, name: "Товар 8" },
    { id: 9, name: "Товар 9" },
    { id: 10, name: "Товар 10" },
    { id: 11, name: "Товар 11" },
    { id: 12, name: "Товар 12" }
  ];
  const itemsPerPage = 6;
  let currentPage = 1;
  let filteredProducts = products;

  function renderProducts() {
    const container = document.getElementById("productsContainer");
    container.innerHTML = "";

    const startIndex = (currentPage - 1) * itemsPerPage;
    const pageItems = filteredProducts.slice(startIndex, startIndex + itemsPerPage);

    for (const item of pageItems) {
      const div = document.createElement("div");

      div.innerHTML = `<img src=${item.image} />`;

      div.innerHTML += `<p>${item.name}<p>`;
      container.appendChild(div);
    }

    renderPagination();
  }

  function renderPagination() {
    const pagination = document.getElementById("pagination");
    pagination.innerHTML = "";

    const pagesCount = Math.ceil(filteredProducts.length / itemsPerPage);

    for (let i = 1; i <= pagesCount; i++) {
      const btn = document.createElement("button");
      btn.textContent = i;
      btn.disabled = i === currentPage;
      btn.addEventListener("click", () => {
        currentPage = i;
        renderProducts();
      });
      pagination.appendChild(btn);
    }
  }

  // Фильтрация товаров по поиску
  const searchInput = document.getElementById("searchInput");
  searchInput.addEventListener("input", () => {
    const query = searchInput.value.toLowerCase();
    filteredProducts = products.filter(p => p.name.toLowerCase().includes(query));
    currentPage = 1;
    renderProducts();
  });

  renderProducts();