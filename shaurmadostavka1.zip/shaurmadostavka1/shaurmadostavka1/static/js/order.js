console.log(sessionStorage.getItem('cart_items'))

const products = [
    { id: 1, name: "Товар 1", image: "/static/images/black.jpg" },
    { id: 2, name: "Товар 2", image: "/static/images/black.jpg" },
    { id: 3, name: "Товар 3", image: "/static/images/black.jpg" },
    { id: 4, name: "Товар 4", image: "/static/images/black.jpg" },
    { id: 5, name: "Товар 5", image: "/static/images/black.jpg" },
    { id: 6, name: "Товар 6", image: "/static/images/black.jpg" },
    { id: 7, name: "Товар 7", image: "/static/images/black.jpg" },
    { id: 8, name: "Товар 8", image: "/static/images/black.jpg" },
    { id: 9, name: "Товар 9", image: "/static/images/black.jpg" },
    { id: 10, name: "Товар 10", image: "/static/images/black.jpg" },
    { id: 11, name: "Товар 11", image: "/static/images/black.jpg" },
    { id: 12, name: "Товар 12", image: "/static/images/black.jpg" }
];

function orderProducts() {
    const cartItems = sessionStorage.getItem('cart_items');
    const container = document.getElementById('products-container');
    container.innerHTML = '';



    if (cartItems) {
        const itemIds = cartItems.split(',').map(id => parseInt(id.trim()));
        
        itemIds.forEach(id => {
            const product = products.find(p => p.id === id);
            if (product) {
                const div = document.createElement('div');
                div.classList.add('product');
                div.innerHTML = `
                    <img src="${product.image}" alt="${product.name}">
                    <p>${product.name}</p>
                    <button class= 'remove-btn' data-id = "${product.id}">Удалить</button>
                `;



                    div.querySelector('.remove-btn').addEventListener('click', () => {
                        console.log('remove from cart clicked');
                        sessionStorage.clear();
                        div.innerHTML = '';
                        div.classList.remove('product');
                        });
                container.appendChild(div);
            }
        });
    }
}

orderProducts();