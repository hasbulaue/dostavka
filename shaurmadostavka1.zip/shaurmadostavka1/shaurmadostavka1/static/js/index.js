

const products = [
  { id: 1, name: "Товар 1", image: "/static/images/black.jpg" },
  { id: 2, name: "Товар 2", image: "/static/images/black.jpg" },
  { id: 3, name: "Товар 3", image: "/static/images/black.jpg" },
  { id: 4, name: "Товар 4", image: "/static/images/black.jpg" },
  { id: 5, name: "Товар 5", image: "/static/images/black.jpg" },
  { id: 6, name: "Товар 6", image: "/static/images/black.jpg" },
  { id: 7, name: "Товар 7", image: "/static/images/black.jpg" },
  { id: 8, name: "Товар 8", image: "/static/images/black.jpg" },
  { id: 9, name: "Товар 9", image: "/static/images/black.jpg" },
  { id: 10, name: "Товар 10", image: "/static/images/black.jpg" },
  { id: 11, name: "Товар 11", image: "/static/images/black.jpg" },
  { id: 12, name: "Товар 12", image: "/static/images/black.jpg" }
];

const itemsPerPage = 6;
let currentPage = 1;
let filteredProducts = products;



function renderProducts() {
  const container = document.getElementById("productsContainer");
  container.innerHTML = "";

  const startIndex = (currentPage - 1) * itemsPerPage;
  const pageItems = filteredProducts.slice(startIndex, startIndex + itemsPerPage);

  for (const item of pageItems) {
    const div = document.createElement("div");
    div.classList.add("product");
    div.innerHTML += `<img src=${item.image} />`;
    div.innerHTML += `<p>${item.name}</p>`;
    div.innerHTML += `<button class="add-to-cart" data-id="${item.id}">Добавить в корзину</button>`;
    


    div.querySelector('.add-to-cart').addEventListener('click', function() {

        
        const currentItems = sessionStorage.getItem('cart_items');
        
        if (currentItems) {

            sessionStorage.setItem('cart_items', currentItems + ',' + this.dataset.id);
        } else {

            sessionStorage.setItem('cart_items', this.dataset.id);
        }
        
        console.log('Товар добавлен в корзину');
        console.log(sessionStorage.getItem('cart_items'));  
    });

  container.appendChild(div);

  }

  renderPagination();

}





function renderPagination() {
  const pagination = document.getElementById("pagination");
  pagination.innerHTML = "";

  const pagesCount = Math.ceil(filteredProducts.length / itemsPerPage);

  for (let i = 1; i <= pagesCount; i++) {
    const btn = document.createElement("button");
    btn.textContent = i;
    btn.disabled = i === currentPage;
    btn.addEventListener("click", () => {
      currentPage = i;
      renderProducts();
    });
    pagination.appendChild(btn);
  }
}

const searchInput = document.getElementById("searchInput");
searchInput.addEventListener("input", () => {
  const query = searchInput.value.toLowerCase();
  filteredProducts = products.filter(p => p.name.toLowerCase().includes(query));
  currentPage = 1;
  renderProducts();
});

renderProducts();