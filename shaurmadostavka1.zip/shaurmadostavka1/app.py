from flask import Flask, render_template, redirect, request

app = Flask(__name__)
searched = []
@app.route("/")
def hello_world():
    return render_template("index.html", searched=searched)


@app.route("/index", methods=["GET", "POST"])
def index():
    if request.method == "POST":
        search = request.form["search"]
        searched.append(search)
        return redirect("/order")

    return render_template("index.html")



@app.route("/order")
def design():
    return render_template("order.html")












app.run(debug=True)