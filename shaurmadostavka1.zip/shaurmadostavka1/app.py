from flask import Flask, render_template, redirect, request

app = Flask(__name__)

@app.route("/")
def hello_world():
    return '<p>Hello, World!</p>'


@app.route("/index", methods=["GET", "POST"])
def index():
    if request.method == "POST":
        search = request.form.get("search")
        print(search)
        return render_template("index.html", products=products)

    return render_template("index.html")



@app.route("/order")
def design():
    return render_template("order.html")












app.run(debug=True)